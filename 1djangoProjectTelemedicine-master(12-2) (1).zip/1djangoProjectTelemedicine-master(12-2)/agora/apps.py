from django.apps import AppConfig


class AgoraConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'agora'
